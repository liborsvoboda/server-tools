## NTypewriter architecture

coming soon