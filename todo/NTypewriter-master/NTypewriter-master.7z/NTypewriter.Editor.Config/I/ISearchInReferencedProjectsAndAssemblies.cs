﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NTypewriter.Editor.Config
{
    public interface ISearchInReferencedProjectsAndAssemblies
    {
        bool SearchInReferencedProjectsAndAssemblies { get; set; }
    }
}