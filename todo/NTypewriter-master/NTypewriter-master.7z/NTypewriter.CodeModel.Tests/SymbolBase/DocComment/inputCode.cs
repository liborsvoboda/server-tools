﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTypewriter.Tests.CodeModel
{
    class SampleClass
    {
        /// <summary>
        /// S1
        /// </summary>
        int integer;

        /// <summary>
        /// S2
        /// </summary>
        /// <returns>R2</returns>
        int[] array;

        List<int> list;
    }
}
