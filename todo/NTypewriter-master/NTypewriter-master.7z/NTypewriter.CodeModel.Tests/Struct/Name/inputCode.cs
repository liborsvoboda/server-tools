﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTypewriter.Tests.CodeModel
{
    internal struct Struct
    {
    }

    internal readonly struct ReadonlyStruct
    {
    }

    internal ref struct RefStruct
    {

    }

    internal record struct RecordStruct
    {
    }

    internal readonly record struct ReadonlyRecordStruct
    {
    }
}
