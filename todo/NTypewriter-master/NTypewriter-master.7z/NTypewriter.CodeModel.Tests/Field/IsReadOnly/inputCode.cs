﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NTypewriter.Tests.CodeModel
{
    class SampleClass
    {
        const int integer = 7;       
        readonly static int? integer2 = 1;
        int[] list;        
    }
}
