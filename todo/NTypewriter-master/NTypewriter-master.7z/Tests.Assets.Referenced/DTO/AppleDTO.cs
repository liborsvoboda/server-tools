﻿using System;
using System.Collections.Generic;
using System.Text;
using Tests.Assets.Referenced.Traits;

namespace Tests.Assets.Referenced.DTO
{
    public class AppleDTO : ICanBeEaten
    {
    }
}
