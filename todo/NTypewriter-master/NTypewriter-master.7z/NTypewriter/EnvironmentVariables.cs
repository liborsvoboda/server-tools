﻿namespace NTypewriter
{
    public class EnvironmentVariables
    {
        public bool IsPreviewRender { get; set; }
    }
}